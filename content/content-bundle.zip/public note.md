public text

public image ("Obsidian Help" local test image)
![[Pasted image 20230712213617.png]]

public image ("Image Not Found" online test image)
<img src="https://s8.gifyu.com/images/Animationc83524d2723e95c3.gif" class="rounded-sm sm:rounded-lg">